<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Data Dosen</title>
    <link rel="stylesheet" href="style-dashboarddosen.css">
</head>
<body>
    <header>
        <h1>Dashboard Admin - Data Dosen</h1>
        <a href="logout.php">Logout</a>
        <button onclick="openTambahDosenModal()">Tambah Dosen</button>
    </header>

    <nav>
        <!-- Navigasi atau menu dapat ditambahkan di sini -->
    </nav>

    <section id="dosen">
        <h2>Data Dosen</h2>
        <!-- Tambahkan ke dalam div dengan id="tambah-dosen-modal" -->
        <div id="tambah-dosen-modal" class="modal">
          <div class="modal-content">
            <span class="close" onclick="closeTambahDosenModal()">&times;</span>
            <h2>Tambah Dosen</h2>
            <!-- Formulir untuk menambahkan dosen -->
                <form id="form-tambah-dosen">
                <label for="nama-dosen">Nama Dosen:</label>
                <input type="text" id="nama-dosen" name="nama-dosen" required>
                <label for="email-dosen">Email Dosen:</label>
                <input type="email" id="email-dosen" name="email-dosen" required>
                <button type="submit">Tambah Dosen</button>
                </form>
        </div>
        </div>

        <table id="dosen-table">
            <thead>
                <tr>
                    <th>ID Dosen</th>
                    <th>Nama Dosen</th>
                    <th>Email</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <!-- Data Dosen akan ditampilkan di sini -->
            </tbody>
        </table>
    </section>

    <footer>
        <p>&copy; 2024 Dashboard Admin</p>
    </footer>
    <script src="js_dosen"></script>
</body>
</html>
