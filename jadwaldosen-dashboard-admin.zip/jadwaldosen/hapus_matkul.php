<?php
// Koneksi ke database (gantilah dengan detail koneksi Anda)
$conn = new mysqli("localhost", "root", "", "jadwal_mata_kuliah");

// Periksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Tangkap ID Mata Kuliah yang akan dihapus
$idMatkul = $_POST['id-matkul'];

// Query untuk menghapus data mata kuliah dari database
$query = "DELETE FROM mata_kuliah WHERE id_matkul = $idMatkul";
$result = $conn->query($query);

// Mengembalikan respons ke JavaScript
if ($result) {
    $response = ['status' => true];
} else {
    $response = ['status' => false];
}

echo json_encode($response);

// Tutup koneksi database
$conn->close();
?>
