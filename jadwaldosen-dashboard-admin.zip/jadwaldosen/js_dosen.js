document.addEventListener('DOMContentLoaded', function () {
    const dosenTableBody = document.querySelector('#dosen-table tbody');

    // Fungsi untuk menambahkan data dosen ke dalam tabel
    function addDosenToTable(data) {
        const newRow = dosenTableBody.insertRow();
        const cells = [
            newRow.insertCell(0),
            newRow.insertCell(1),
            newRow.insertCell(2),
            newRow.insertCell(3),
        ];

        cells[0].textContent = data.id_dosen;
        cells[1].textContent = data.nama_dosen;
        cells[2].textContent = data.email;
        
        // Tambahkan tombol Aksi (Edit/Hapus) jika diperlukan
        const actionCell = cells[3];
        const editButton = document.createElement('button');
        editButton.textContent = 'Edit';
        // Tambahkan event listener untuk menangani aksi edit
        editButton.addEventListener('click', function () {
            editDosen(data.id_dosen);
        });
         // Tambahkan event listener untuk tombol "Tambah Dosen"
         const tambahDosenButton = document.querySelector('#header button');
         tambahDosenButton.addEventListener('click', openTambahDosenModal);
        // Sama seperti tombol Edit, Anda dapat menambahkan tombol Hapus
        // ...

        actionCell.appendChild(editButton);
        
    }

    // Fungsi untuk memuat data dosen dari server
    function loadDosen() {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', 'get_dosen.php', true);

        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                const dosen = JSON.parse(xhr.responseText);

                // Menambahkan data dosen ke dalam tabel
                dosen.forEach(function (dosenData) {
                    addDosenToTable(dosenData);
                });
            }
        };

        xhr.send();
    }

    // Memuat data dosen saat halaman dimuat
    loadDosen();
    
    // Fungsi untuk menangani aksi edit dosen
    function editDosen(idDosen) {
        // Implementasi logika untuk mengarahkan ke halaman edit dosen
        // ...
        alert('Edit Dosen dengan ID ' + idDosen);
    }
    // Tambahkan ke dalam script.js
    function openTambahDosenModal() {
    // Implementasikan logika untuk membuka modal tambah dosen
    alert('Buka modal tambah dosen');
    }
    // Tambahkan ke dalam script.js
    function closeTambahDosenModal() {
    // Implementasikan logika untuk menutup modal tambah dosen
    alert('Tutup modal tambah dosen');
    }
    // Tambahkan ke dalam script.js
    function openTambahDosenModal() {
    const tambahDosenModal = document.getElementById('tambah-dosen-modal');
    tambahDosenModal.style.display = 'block';
    }
    // Tambahkan ke dalam script.js
    function closeTambahDosenModal() {
    const tambahDosenModal = document.getElementById('tambah-dosen-modal');
    tambahDosenModal.style.display = 'none';
    }
     // Tambahkan event listener untuk formulir tambah dosen
        const tambahDosenForm = document.getElementById('form-tambah-dosen');
 tambahDosenForm.addEventListener('submit', function (event) {
     event.preventDefault(); // Menghentikan pengiriman formulir

     // Ambil data dari formulir
     const namaDosen = document.getElementById('nama-dosen').value;
     const emailDosen = document.getElementById('email-dosen').value;

     // Panggil fungsi untuk menambahkan dosen
     tambahkanDosen(namaDosen, emailDosen);

     // Tutup modal setelah menambahkan dosen
     closeTambahDosenModal();
 });
// Tambahkan ke dalam script.js
function tambahkanDosen(namaDosen, emailDosen) {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'tambah_dosen.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            const response = JSON.parse(xhr.responseText);

            if (response.status) {
                // Jika penambahan sukses, tambahkan dosen ke dalam tabel
                const dosenData = { id_dosen: response.id, nama_dosen, email: emailDosen };
                addDosenToTable(dosenData);
                alert('Dosen berhasil ditambahkan!');
            } else {
                alert('Gagal menambahkan dosen. Silakan coba lagi.');
            }
        }
    };

    // Kirim data ke server
    xhr.send(`nama-dosen=${namaDosen}&email-dosen=${emailDosen}`);
    
}

// Tambahkan ke dalam script.js
document.addEventListener('DOMContentLoaded', function () {
    // ... (fungsi loadDosen dan lainnya)

    // Tambahkan event listener untuk formulir tambah dosen
    const tambahDosenForm = document.getElementById('form-tambah-dosen');
    tambahDosenForm.addEventListener('submit', function (event) {
        event.preventDefault(); // Menghentikan pengiriman formulir

        // Ambil data dari formulir
        const namaDosen = document.getElementById('nama-dosen').value;
        const emailDosen = document.getElementById('email-dosen').value;

        // Panggil fungsi untuk menambahkan dosen
        tambahkanDosen(namaDosen, emailDosen);

        // Tutup modal setelah menambahkan dosen
        closeTambahDosenModal();
    });

    // Tambahkan event listener untuk tombol "Tambah Dosen"
    const tambahDosenButton = document.querySelector('header button');
    tambahDosenButton.addEventListener('click', openTambahDosenModal);

    // Tambahkan event listener untuk tombol "Hapus" pada setiap baris tabel
    const dosenTableBody = document.querySelector('#dosen-table tbody');
    dosenTableBody.addEventListener('click', function (event) {
        const target = event.target;

        // Periksa apakah tombol yang diklik adalah tombol "Hapus"
        if (target.tagName === 'BUTTON' && target.classList.contains('hapus-button')) {
            // Ambil ID Dosen dari atribut data-id pada tombol "Hapus"
            const idDosen = target.getAttribute('data-id');

            // Panggil fungsi untuk menghapus dosen
            hapusDosen(idDosen);
        }
    });
});

// Fungsi untuk menambahkan tombol "Hapus" pada setiap baris tabel
function tambahkanTombolHapus(idDosen) {
    const dosenTableBody = document.querySelector('#dosen-table tbody');

    // Cari baris tabel dengan ID Dosen yang sesuai
    const barisTabel = Array.from(dosenTableBody.children).find(row => row.cells[0].textContent === idDosen);

    // Tambahkan tombol "Hapus" jika belum ada
    if (barisTabel) {
        const cellAksi = barisTabel.insertCell(-1);
        const tombolHapus = document.createElement('button');
        tombolHapus.textContent = 'Hapus';
        tombolHapus.classList.add('hapus-button');
        tombolHapus.setAttribute('data-id', idDosen);
        cellAksi.appendChild(tombolHapus);
    }
}

// Fungsi untuk menghapus tombol "Hapus" pada setiap baris tabel
function hapusTombolHapus(idDosen) {
    const dosenTableBody = document.querySelector('#dosen-table tbody');

    // Cari baris tabel dengan ID Dosen yang sesuai
    const barisTabel = Array.from(dosenTableBody.children).find(row => row.cells[0].textContent === idDosen);

    // Hapus tombol "Hapus" jika ada
    if (barisTabel) {
        barisTabel.deleteCell(-1);
    }
}

// Fungsi untuk menangani penghapusan dosen
function hapusDosen(idDosen) {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'hapus_dosen.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            const response = JSON.parse(xhr.responseText);

            if (response.status) {
                // Jika penghapusan sukses, hapus baris tabel
                const dosenTableBody = document.querySelector('#dosen-table tbody');
                const barisTabel = Array.from(dosenTableBody.children).find(row => row.cells[0].textContent === idDosen);

                if (barisTabel) {
                    dosenTableBody.removeChild(barisTabel);
                }

                // Hapus tombol "Hapus" dari baris tabel
                hapusTombolHapus(idDosen);

                alert('Dosen berhasil dihapus!');
            } else {
                alert('Gagal menghapus dosen. Silakan coba lagi.');
            }
        }
    };

    // Kirim data ke server
    xhr.send(`id-dosen=${idDosen}`);
}

});

