<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Dashboard Admin - Data Mata Kuliah</title>
</head>
<body>
    <header>
        <h1>Data Mata Kuliah</h1>
        <a href="logout.php">Logout</a>
        <button onclick="openTambahMatkulModal()">Tambah Mata Kuliah</button>
    </header>

    <section id="matkul">
        <h2>Data Mata Kuliah</h2>
        <table id="matkul-table">
            <thead>
                <tr>
                    <th>ID Mata Kuliah</th>
                    <th>Nama Mata Kuliah</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <!-- Data Mata Kuliah akan ditampilkan di sini -->
            </tbody>
        </table>
    </section>

    <div id="tambah-matkul-modal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeTambahMatkulModal()">&times;</span>
            <h2>Tambah Mata Kuliah</h2>
            <!-- Formulir tambah mata kuliah akan ditambahkan di sini -->
            <!-- Tambahkan ke dalam div dengan id="tambah-matkul-modal" -->
                <form id="form-tambah-matkul">
                <label for="nama-matkul">Nama Mata Kuliah:</label>
                <input type="text" id="nama-matkul" name="nama-matkul" required>
                <button type="submit">Tambah Mata Kuliah</button>
</form>

        </div>
    </div>

    <script src="script_admin.js"></script>
</body>
</html>
