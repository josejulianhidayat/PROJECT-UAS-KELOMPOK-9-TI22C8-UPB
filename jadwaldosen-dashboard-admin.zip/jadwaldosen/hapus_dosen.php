<?php
// Koneksi ke database (gantilah dengan detail koneksi Anda)
$conn = new mysqli("localhost", "root", "", "dosen");

// Periksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Tangkap ID Dosen yang akan dihapus
$idDosen = $_POST['id-dosen'];

// Query untuk menghapus data dosen dari database
$query = "DELETE FROM dosen WHERE id_dosen = $idDosen";
$result = $conn->query($query);

// Mengembalikan respons ke JavaScript
if ($result) {
    $response = ['status' => true];
} else {
    $response = ['status' => false];
}

echo json_encode($response);

// Tutup koneksi database
$conn->close();
?>
