<?php
// Koneksi ke database (gantilah dengan detail koneksi Anda)
$conn = new mysqli("localhost", "root", "", "jadwal_mata_kuliah");

// Periksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Tangkap data dari formulir tambah mata kuliah
$namaMatkul = $_POST['nama-matkul'];

// Query untuk menambahkan data mata kuliah ke dalam database
$query = "INSERT INTO mata_kuliah (nama_matkul) VALUES ('$namaMatkul')";
$result = $conn->query($query);

// Mengembalikan respons ke JavaScript
if ($result) {
    $response = ['status' => true, 'id' => $conn->insert_id];
} else {
    $response = ['status' => false];
}

echo json_encode($response);

// Tutup koneksi database
$conn->close();
?>
