<!DOCTYPE html>
<html lang="en">
<head>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style_admin.css">
	< <script src="script_admin.js"></script> 
	<!-- Script: menambahkan logika JavaScript untuk mengelola data yang dimasukkan ke dalam formulir.  -->
    <title>Admin Dashboard - Penjadwalan Dosen</title>
</head>
</head>
<body>
	<?php 
	session_start();
 
	// cek apakah yang mengakses halaman ini sudah login
	if($_SESSION['level']==""){
		header("location:index.php?pesan=gagal");
	}
	
	?>
	<div class="admin-dashboard">
	<header>
            <h1>Admin Dashboard</h1>
	</header>
	<nav>
            <ul>
                <li><a href="#schedule">Penjadwalan</a></li>
                <li><a href="#lecturers">Data Dosen</a></li>
                <li><a href="#courses">Data Mata Kuliah</a></li>
				<a href="logout.php">Logout</a>
				
            </ul>
    </nav>
	<main>
            <section id="schedule">
                <h2>Penjadwalan Dosen</h2>
                <!-- Form atau konten penjadwalan dapat ditambahkan di sini -->
				<form id="schedule-form" action="save_schedule.php" method="post">
        			<label for="lecturer">Dosen:</label>
        				<select name="lecturer" id="lecturer">
          		  		<!-- Opsi dosen akan diisi dinamis dari database atau sumber data lainnya -->
           					 <option value="1">Ermanto, S.Pd.,M.Kom.</option>
            				 <option value="2">Sufajar Butsianto, S.Kom.,M.Kom</option>
							 <option value="3">Asep Arwan Sulaeman, S.T.,M.Kom.</option>
							 <option value="4">Sugiyatno, S.Kom.,M.Kom.</option>
							 <option value="5">Sophian Andhika Sardi, S.Kom.,M.Kom.</option>
							 <option value="6">Karsito, S.Kom.,M.Kom.</option>
							 <option value="7">Dr.(C) Ir U Darmanto,M.Kom.</option>
           		  		<!-- ... Opsi dosen lainnya ... -->
           	 			</section>
        					<select name="course" id="course">
            			<!-- Opsi mata kuliah akan diisi dinamis dari database atau sumber data lainnya -->
            				<option value="1">Pemrograman Web 1</option>
            				<option value="2">Probabilitas Dan Statistika</option>
							<option value="3">Pemrograman Berorientasi Object</option>
							<option value="4">Pemrograman Mobile 1</option>
							<option value="5">Rekayasa Perangkat Lunak</option>
							<option value="6">Jaringan Komputer</option>
							<option value="7">Pendidikan Agama 3</option>
							<option value="8">Logika Informatika</option>

            			<!-- ... Opsi mata kuliah lainnya ... -->
        				</select>
						<p>SILAHKAN PILIH MATA KULIAH DIATAS</P>
					<label for="course">Mata Kuliah:</label>	
						<select name="course" id="course">
            			<!-- Opsi mata kuliah akan diisi dinamis dari database atau sumber data lainnya -->
            				<option value="1">Pemrograman Web 1</option>
            				<option value="2">Probabilitas Dan Statistika</option>
							<option value="3">Pemrograman Berorientasi Object</option>
							<option value="4">Pemrograman Mobile 1</option>
							<option value="5">Rekayasa Perangkat Lunak</option>
							<option value="6">Jaringan Komputer</option>
							<option value="7">Pendidikan Agama 3</option>
							<option value="8">Logika Informatika</option>

            			<!-- ... Opsi mata kuliah lainnya ... -->
        				</select>
        			<label for="day">Hari:</label>
     		   			<select name="day" id="day">
            				<option value="Monday">Senin</option>
            				<option value="Tuesday">Selasa</option>
            				<option value="Wednesday">Rabu</option>
            				<option value="Thursday">Kamis</option>
            				<option value="Friday">Jumat</option>
							<option value="Saturday">Sabtu</option>
							<option value="Sunday">Minggu</option>
            			<!-- ... Opsi hari lainnya ... -->
        				</select>
        			<label for="start-time">Waktu Mulai:</label>
        			<input type="time" name="start-time" id="start-time">
        			<label for="end-time">Waktu Selesai:</label>
        			<input type="time" name="end-time" id="end-time">
					<label for="room">Ruangan:</label>
        			<input type="text" name="room" id="room" placeholder="Contoh: A101">

        				<button type="submit">Tambah Jadwal</button>
    			</form>
				<!--Tambahkan tabel di bawah formulir untuk menampilkan jadwal yang telah ditambahkan. -->
				<h2>Daftar Jadwal</h2>
       				 <table id="schedule-table">
           				 <thead>
               			 <tr>
                 		   	<th>Dosen</th>
                   			<th>Mata Kuliah</th>
                    		<th>Hari</th>
                    		<th>Waktu Mulai</th>
                    		<th>Waktu Selesai</th>
                    		<th>Ruangan</th>
                		</tr>
            			</thead>
          		  		<tbody>
                		<!-- Data jadwal akan ditampilkan di sini -->
          		  		</tbody>
       		 		</table>
			</section>
            <section id="lecturers">
                <h2>Data Dosen</h2>
				
				<!-- Tambahkan ke dalam div dengan id="tambah-dosen-modal" -->
					<form id="form-tambah-dosen">
    				<label for="nama-dosen">Nama Dosen:</label>
    				<input type="text" id="nama-dosen" name="nama-dosen" required>
    				<label for="email-dosen">Email Dosen:</label>
    				<input type="email" id="email-dosen" name="email-dosen" required>
    				<button type="submit">Tambah Dosen</button>
					</form>

                <!-- Tabel atau konten data dosen dapat ditambahkan di sini -->
				<table id="dosen-table">
       			<thead>
            	<tr>
                	<th>ID Dosen</th>
                	<th>Nama Dosen</th>
                	<th>Email</th>
                	<th>Aksi</th>
            	</tr>
        		</thead>
        		<tbody>
            	<!-- Data Dosen akan ditampilkan di sini -->
        		</tbody>
    			</table>
            </section>
            <section id="courses">
                <h2>Data Mata Kuliah</h2>
				<button onclick="openMataKuliahPage()">Data Mata Kuliah</button>
                <!-- Tabel atau konten data mata kuliah dapat ditambahkan di sini -->
				<!-- Tambahkan ke dalam div dengan id="tambah-matkul-modal" -->
			<form id="form-tambah-matkul">
  			<label for="nama-matkul">Nama Mata Kuliah:</label>
   			 <input type="text" id="nama-matkul" name="nama-matkul" required>

   			 <button type="submit">Tambah Mata Kuliah</button>
			</form>

            </section>
    </main>
	</div>
	<br/>
	<br/>
 
</body>
</html>
