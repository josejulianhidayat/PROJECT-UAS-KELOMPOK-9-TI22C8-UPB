<?php
// Koneksi ke database (gantilah dengan detail koneksi Anda)
$conn = new mysqli("localhost", "root", "", "jadwal");

// Periksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ambil data dari formulir
$lecturer = $_POST['lecturer'];
$course = $_POST['course'];
$day = $_POST['day'];
$startTime = $_POST['start_time'];
$endTime = $_POST['end_time'];
$room = $_POST['room'];

// Query untuk menyimpan data ke dalam database
$query = "INSERT INTO jadwal (dosen, mata_kuliah, hari, waktu_mulai, waktu_selesai, ruangan) VALUES ('$lecturer', '$course', '$day', '$startTime', '$endTime', '$room')";

// Eksekusi query
if ($conn->query($query) === TRUE) {
    echo "Jadwal berhasil disimpan";
} else {
    echo "Error: " . $query . "<br>" . $conn->error;
}

// Tutup koneksi database
$conn->close();
?>
