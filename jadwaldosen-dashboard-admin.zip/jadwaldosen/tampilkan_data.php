<?php
// Fungsi untuk menampilkan data dosen
function tampilkanDataDosen() {
    // Implementasikan logika untuk mengambil data dosen dari database
    // ...
    // Contoh:
    echo '<tr><td>1</td><td>John Doe</td><td>john@example.com</td></tr>';
    echo '<tr><td>2</td><td>Jane Smith</td><td>jane@example.com</td></tr>';
}

// Fungsi untuk menampilkan data mata kuliah
function tampilkanDataMatkul() {
    // Implementasikan logika untuk mengambil data mata kuliah dari database
    // ...
    // Contoh:
    echo '<tr><td>101</td><td>Matematika</td><td><button class="hapus-button" data-id="101">Hapus</button></td></tr>';
    echo '<tr><td>102</td><td>Fisika</td><td><button class="hapus-button" data-id="102">Hapus</button></td></tr>';
}

// Fungsi untuk menampilkan data penjadwalan dosen
function tampilkanDataPenjadwalan() {
    // Implementasikan logika untuk mengambil data penjadwalan dosen dari database
    // ...
    // Contoh:
    echo '<tr><td>1</td><td>1</td><td>101</td><td>Senin</td><td>08:00</td><td>10:00</td><td>Ruang 101</td><td><button class="hapus-button" data-id="1">Hapus</button></td></tr>';
    echo '<tr><td>2</td><td>2</td><td>102</td><td>Rabu</td><td>10:00</td><td>12:00</td><td>Ruang 102</td><td><button class="hapus-button" data-id="2">Hapus</button></td></tr>';
}
?>
