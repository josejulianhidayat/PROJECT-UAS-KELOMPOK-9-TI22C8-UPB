<?php
// Koneksi ke database (gantilah dengan detail koneksi Anda)
$conn = new mysqli("localhost", "root", "", "dosen");

// Periksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Tangkap data dari formulir tambah dosen
$namaDosen = $_POST['nama-dosen'];
$emailDosen = $_POST['email-dosen'];

// Query untuk menambahkan data dosen ke dalam database
$query = "INSERT INTO dosen (nama_dosen, email) VALUES ('$namaDosen', '$emailDosen')";
$result = $conn->query($query);

// Mengembalikan respons ke JavaScript
if ($result) {
    $response = ['status' => true, 'id' => $conn->insert_id];
} else {
    $response = ['status' => false];
}

echo json_encode($response);

// Tutup koneksi database
$conn->close();

// Tutup koneksi database
$conn->close();

// Mengembalikan respons ke JavaScript
echo json_encode(['status' => $result]);
?>
