<?php
// Koneksi ke database (gantilah dengan detail koneksi Anda)
$conn = new mysqli("localhost", "root", "", "dosen");

// Periksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query untuk mengambil data dosen dari database
$query = "SELECT * FROM dosen";
$result = $conn->query($query);

// Array untuk menyimpan data dosen
$dosen = array();

// Mengambil hasil query dan menyimpannya dalam array
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $dosen[] = $row;
    }
}

// Mengembalikan data dalam format JSON
echo json_encode($dosen);

// Tutup koneksi database
$conn->close();
?>
