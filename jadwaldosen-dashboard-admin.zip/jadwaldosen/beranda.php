<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Kampus Dashboard</title>
</head>
<body>
    <div class="dashboard">
        <header>
            <h1>Kampus Dashboard</h1>
        </header>
        <nav>
            <ul>
                <li><a href="#dosen">Data Dosen</a></li>
                <li><a href="#matakuliah">Data Mata Kuliah</a></li>
                <li><a href="#ruangan">Data Ruangan</a></li>
            </ul>
        </nav>
        <main>
            <section id="dosen">
                <h2>Data Dosen</h2>
                <!-- Tambahkan elemen lainnya -->
            </section>
            <section id="matakuliah">
                <h2>Data Mata Kuliah</h2>
                <!-- Tambahkan elemen lainnya -->
            </section>
            <section id="ruangan">
                <h2>Data Ruangan</h2>
                <!-- Tambahkan elemen lainnya -->
            </section>
        </main>
    </div>
</body>
</html>
