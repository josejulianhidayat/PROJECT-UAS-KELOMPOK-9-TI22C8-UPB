<?php
// Koneksi ke database (gantilah dengan detail koneksi Anda)
$conn = new mysqli("localhost", "root", "", "save_schedule");

// Periksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query untuk mengambil data jadwal dari database
$query = "SELECT * FROM jadwal";
$result = $conn->query($query);

// Array untuk menyimpan data jadwal
$schedules = array();

// Mengambil hasil query dan menyimpannya dalam array
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $schedules[] = $row;
    }
}

// Mengembalikan data dalam format JSON
echo json_encode($schedules);

// Tutup koneksi database
$conn->close();
?>
