document.addEventListener('DOMContentLoaded', function () {
    const scheduleForm = document.getElementById('schedule-form');
    const scheduleTableBody = document.querySelector('#schedule-table tbody');

    // Fungsi untuk menambahkan jadwal ke dalam tabel
    function addScheduleToTable(data) {
        const newRow = scheduleTableBody.insertRow();
        const cells = [
            newRow.insertCell(0),
            newRow.insertCell(1),
            newRow.insertCell(2),
            newRow.insertCell(3),
            newRow.insertCell(4),
            newRow.insertCell(5),
            newRow.insertCell(6),
        ];

        cells[0].textContent = data.dosen;
        cells[1].textContent = data.mata_kuliah;
        cells[2].textContent = data.hari;
        cells[3].textContent = data.waktu_mulai;
        cells[4].textContent = data.waktu_selesai;
        cells[5].textContent = data.ruangan;

        // Tambahkan tombol Hapus
        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Hapus';
        deleteButton.addEventListener('click', function () {
            deleteSchedule(newRow);
        });
        cells[6].appendChild(deleteButton);
    }

    // Fungsi untuk menghapus jadwal dari tabel dan database
    function deleteSchedule(row) {
        const index = row.rowIndex;

        // Hapus baris dari tabel
        scheduleTableBody.deleteRow(index);

        // TODO: Tambahkan logika untuk menghapus data dari database

        alert('Jadwal berhasil dihapus');
    }

    // Fungsi untuk memuat jadwal dari server
    function loadSchedules() {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', 'get_schedule.php', true);

        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                const schedules = JSON.parse(xhr.responseText);

                // Menambahkan jadwal ke dalam tabel
                schedules.forEach(function (schedule) {
                    addScheduleToTable(schedule);
                });
            }
        };

        xhr.send();
    }

    // Memuat jadwal saat halaman dimuat
    loadSchedules();

    // Fungsi untuk menangani pengiriman formulir
    scheduleForm.addEventListener('submit', function (event) {
        event.preventDefault();

        // Ambil nilai dari formulir
        const lecturer = document.getElementById('lecturer').value;
        const course = document.getElementById('course').value;
        const day = document.getElementById('day').value;
        const startTime = document.getElementById('start-time').value;
        const endTime = document.getElementById('end-time').value;
        const room = document.getElementById('room').value;

        // Validasi sederhana (Anda dapat menambahkan validasi lebih lanjut)
        if (!lecturer || !course || !day || !startTime || !endTime || !room) {
            alert('Harap lengkapi semua field!');
            return;
        }

        // Kirim data ke server menggunakan AJAX
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'save_schedule.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                // Jika data berhasil disimpan, tambahkan jadwal ke dalam tabel
                addScheduleToTable({
                    dosen: lecturer,
                    mata_kuliah: course,
                    hari: day,
                    waktu_mulai: startTime,
                    waktu_selesai: endTime,
                    ruangan: room
                });

                // Reset formulir setelah pengiriman berhasil
                scheduleForm.reset();
                alert(xhr.responseText);
            }
        };

        const formData = `lecturer=${lecturer}&course=${course}&day=${day}&start_time=${startTime}&end_time=${endTime}&room=${room}`;
        xhr.send(formData);
    });
});
function openMataKuliahPage() {
    window.location.href = 'dashboard_matkul.php';
}
// Tambahkan ke dalam script.js
function openTambahMatkulModal() {
    const tambahMatkulModal = document.getElementById('tambah-matkul-modal');
    tambahMatkulModal.style.display = 'block';
}

function closeTambahMatkulModal() {
    const tambahMatkulModal = document.getElementById('tambah-matkul-modal');
    tambahMatkulModal.style.display = 'none';
}
// Tambahkan ke dalam script.js pada event listener 'DOMContentLoaded'
document.addEventListener('DOMContentLoaded', function () {
    // ... (fungsi loadMatkul dan lainnya)

    // Tambahkan event listener untuk tombol "Hapus" pada setiap baris tabel mata kuliah
    const matkulTableBody = document.querySelector('#matkul-table tbody');
    matkulTableBody.addEventListener('click', function (event) {
        const target = event.target;

        // Periksa apakah tombol yang diklik adalah tombol "Hapus"
        if (target.tagName === 'BUTTON' && target.classList.contains('hapus-button')) {
            // Ambil ID Mata Kuliah dari atribut data-id pada tombol "Hapus"
            const idMatkul = target.getAttribute('data-id');

            // Panggil fungsi untuk menghapus mata kuliah
            hapusMatkul(idMatkul);
        }
    });
});

// Fungsi untuk menambahkan tombol "Hapus" pada setiap baris tabel mata kuliah
function tambahkanTombolHapusMatkul(idMatkul) {
    const matkulTableBody = document.querySelector('#matkul-table tbody');

    // Cari baris tabel dengan ID Mata Kuliah yang sesuai
    const barisTabel = Array.from(matkulTableBody.children).find(row => row.cells[0].textContent === idMatkul);

    // Tambahkan tombol "Hapus" jika belum ada
    if (barisTabel) {
        const cellAksi = barisTabel.insertCell(-1);
        const tombolHapus = document.createElement('button');
        tombolHapus.textContent = 'Hapus';
        tombolHapus.classList.add('hapus-button');
        tombolHapus.setAttribute('data-id', idMatkul);
        cellAksi.appendChild(tombolHapus);
    }
}

// Fungsi untuk menghapus tombol "Hapus" pada setiap baris tabel mata kuliah
function hapusTombolHapusMatkul(idMatkul) {
    const matkulTableBody = document.querySelector('#matkul-table tbody');

    // Cari baris tabel dengan ID Mata Kuliah yang sesuai
    const barisTabel = Array.from(matkulTableBody.children).find(row => row.cells[0].textContent === idMatkul);

    // Hapus tombol "Hapus" jika ada
    if (barisTabel) {
        barisTabel.deleteCell(-1);
    }
}

// Fungsi untuk menangani penghapusan mata kuliah
function hapusMatkul(idMatkul) {
    // Implementasikan logika penghapusan mata kuliah sesuai kebutuhan Anda
    // ...
    alert(`Mata Kuliah dengan ID ${idMatkul} berhasil dihapus!`);
}
// Tambahkan ke dalam script.js
function openTambahMatkulModal() {
    const tambahMatkulModal = document.getElementById('tambah-matkul-modal');
    tambahMatkulModal.style.display = 'block';
}

function closeTambahMatkulModal() {
    const tambahMatkulModal = document.getElementById('tambah-matkul-modal');
    tambahMatkulModal.style.display = 'none';
}

document.addEventListener('DOMContentLoaded', function () {
    // ... (fungsi loadMatkul dan lainnya)

    // Tambahkan event listener untuk formulir tambah mata kuliah
    const tambahMatkulForm = document.getElementById('form-tambah-matkul');
    tambahMatkulForm.addEventListener('submit', function (event) {
        event.preventDefault(); // Menghentikan pengiriman formulir

        // Ambil data dari formulir
        const namaMatkul = document.getElementById('nama-matkul').value;

        // Panggil fungsi untuk menambahkan mata kuliah
        tambahkanMatkul(namaMatkul);

        // Tutup modal setelah menambahkan mata kuliah
        closeTambahMatkulModal();
    });
});

// Fungsi untuk menambahkan mata kuliah
function tambahkanMatkul(namaMatkul) {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'tambah_matkul.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            const response = JSON.parse(xhr.responseText);

            if (response.status) {
                // Jika penambahan sukses, tambahkan data ke dalam tabel
                tambahkanBarisMatkul(response.id, namaMatkul);
                alert('Mata Kuliah berhasil ditambahkan!');
            } else {
                alert('Gagal menambahkan mata kuliah. Silakan coba lagi.');
            }
        }
    };

    // Kirim data ke server
    xhr.send(`nama-matkul=${encodeURIComponent(namaMatkul)}`);
}

// Fungsi untuk menambahkan baris mata kuliah ke dalam tabel
function tambahkanBarisMatkul(idMatkul, namaMatkul) {
    const matkulTableBody = document.querySelector('#matkul-table tbody');
    const barisTabel = matkulTableBody.insertRow(-1);

    // Tambahkan sel-sel pada baris tabel
    const cellIdMatkul = barisTabel.insertCell(0);
    const cellNamaMatkul = barisTabel.insertCell(1);
    const cellAksi = barisTabel.insertCell(2);

    // Isi data ke dalam sel-sel
    cellIdMatkul.textContent = idMatkul;
    cellNamaMatkul.textContent = namaMatkul;

    // Tambahkan tombol "Hapus" pada baris tabel
    tambahkanTombolHapusMatkul(idMatkul);
}
