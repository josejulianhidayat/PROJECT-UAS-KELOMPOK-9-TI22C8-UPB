document.addEventListener('DOMContentLoaded', function () {
    const scheduleForm = document.getElementById('schedule-form');
    const scheduleTableBody = document.querySelector('#schedule-table tbody');

    scheduleForm.addEventListener('submit', function (event) {
        event.preventDefault();

        // Ambil nilai dari formulir
        const lecturer = document.getElementById('lecturer').value;
        const course = document.getElementById('course').value;
        const day = document.getElementById('day').value;
        const startTime = document.getElementById('start-time').value;
        const endTime = document.getElementById('end-time').value;
        const room = document.getElementById('room').value;

        // Validasi sederhana (Anda dapat menambahkan validasi lebih lanjut)
        if (!lecturer || !course || !day || !startTime || !endTime || !room) {
            alert('Harap lengkapi semua field!');
            return;
        }

        // Menambahkan jadwal ke dalam tabel
        const newRow = scheduleTableBody.insertRow();
        const cells = [
            newRow.insertCell(0),
            newRow.insertCell(1),
            newRow.insertCell(2),
            newRow.insertCell(3),
            newRow.insertCell(4),
            newRow.insertCell(5),
        ];

        cells[0].textContent = lecturer;
        cells[1].textContent = course;
        cells[2].textContent = day;
        cells[3].textContent = startTime;
        cells[4].textContent = endTime;
        cells[5].textContent = room;


        function loadSchedules() {
            const xhr = new XMLHttpRequest();
            xhr.open('GET', 'get_schedule.php', true);
    
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    const schedules = JSON.parse(xhr.responseText);
    
                    // Menambahkan jadwal ke dalam tabel
                    schedules.forEach(function (schedule) {
                        addScheduleToTable(schedule);
                    });
                }
            };
    
            xhr.send();
        }
    
        // Memuat jadwal saat halaman dimuat
        loadSchedules();
    
        // Fungsi untuk menangani pengiriman formulir
        scheduleForm.addEventListener('submit', function (event) {
            event.preventDefault();
    
            // ... (Kode pengiriman formulir tetap sama)
    
            // Kirim data ke server menggunakan AJAX
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'save_schedule.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    // Jika data berhasil disimpan, tambahkan jadwal ke dalam tabel
                    addScheduleToTable({
                        dosen: lecturer,
                        mata_kuliah: course,
                        hari: day,
                        waktu_mulai: startTime,
                        waktu_selesai: endTime,
                        ruangan: room
                    });
    
                    // Reset formulir setelah pengiriman berhasil
                    scheduleForm.reset();
                    alert(xhr.responseText);
                }
            };
    
            const formData = `lecturer=${lecturer}&course=${course}&day=${day}&start_time=${startTime}&end_time=${endTime}&room=${room}`;
            xhr.send(formData);
        });
   
    });
    function addScheduleToTable(data) {
        const newRow = scheduleTableBody.insertRow();
        const cells = [
            newRow.insertCell(0),
            newRow.insertCell(1),
            newRow.insertCell(2),
            newRow.insertCell(3),
            newRow.insertCell(4),
            newRow.insertCell(5),
            newRow.insertCell(6), // Kolom baru untuk tombol Hapus
        ];

        cells[0].textContent = data.dosen;
        cells[1].textContent = data.mata_kuliah;
        cells[2].textContent = data.hari;
        cells[3].textContent = data.waktu_mulai;
        cells[4].textContent = data.waktu_selesai;
        cells[5].textContent = data.ruangan;

        // Tambahkan tombol Hapus
        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Hapus';
        deleteButton.addEventListener('click', function () {
            deleteSchedule(newRow);
        });
        cells[6].appendChild(deleteButton);
    }

    // Fungsi untuk menghapus jadwal dari tabel dan database
    function deleteSchedule(row) {
        const index = row.rowIndex;

        // Hapus baris dari tabel
        scheduleTableBody.deleteRow(index);

        // TODO: Tambahkan logika untuk menghapus data dari database

        alert('Jadwal berhasil dihapus');
    } // ... (Fungsi lainnya tetap sama)

    // Memuat jadwal saat halaman dimuat
    loadSchedules();

    // ... (Logika pengiriman formulir tetap sama)
});
